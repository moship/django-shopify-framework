from setuptools import setup

setup(
    install_requires=[
        'cryptography',
        'requests'
    ]
)