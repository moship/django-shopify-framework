from django.apps import AppConfig


class ShopifyFrameworkConfig(AppConfig):
    name = 'shopify_framework'
